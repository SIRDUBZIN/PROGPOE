using Microsoft.AspNetCore.Identity;
using RaceDayMVC.Models;
namespace RaceDayMVC.Data;
public static class RoleSeeder
{
 public static async Task SeedAsync(IServiceProvider services, IConfiguration config)
 {
  var roles=services.GetRequiredService<RoleManager<IdentityRole>>();
  foreach(var role in new[]{"Admin","Organiser","Participant"}) if(!await roles.RoleExistsAsync(role)) await roles.CreateAsync(new IdentityRole(role));
  var users=services.GetRequiredService<UserManager<ApplicationUser>>();
  var email=config["SeedAdmin:Email"]; var password=config["SeedAdmin:Password"];
  if(!string.IsNullOrWhiteSpace(email)&&!string.IsNullOrWhiteSpace(password)) {
   var admin=await users.FindByEmailAsync(email);
   if(admin==null){admin=new ApplicationUser{UserName=email,Email=email,EmailConfirmed=true,FirstName="System",LastName="Administrator"}; var created=await users.CreateAsync(admin,password); if(created.Succeeded) await users.AddToRoleAsync(admin,"Admin");}
   else if(!await users.IsInRoleAsync(admin,"Admin")) await users.AddToRoleAsync(admin,"Admin");
  }
 }
}