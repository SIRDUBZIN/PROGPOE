using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RaceDayMVC.Models;
namespace RaceDayMVC.Data;
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
 public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options){}
 public DbSet<Event> Events => Set<Event>(); public DbSet<Category> Categories => Set<Category>();
 public DbSet<Enrollment> Enrollments => Set<Enrollment>(); public DbSet<Result> Results => Set<Result>();
 protected override void OnModelCreating(ModelBuilder builder)
 {
  base.OnModelCreating(builder);
  builder.Entity<Event>().Property(x=>x.Distance).HasPrecision(6,2);
  builder.Entity<Event>().ToTable(t=>t.HasCheckConstraint("CK_Events_EventType", "[EventType] IN ('Run','Walk','Cycle')"));
  builder.Entity<Event>().ToTable(t=>t.HasCheckConstraint("CK_Events_Distance", "[Distance] > 0"));
  builder.Entity<Event>().HasOne(x=>x.Organiser).WithMany(x=>x.OrganisedEvents).HasForeignKey(x=>x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
  builder.Entity<Category>().HasOne(x=>x.Event).WithMany(x=>x.Categories).HasForeignKey(x=>x.EventId).OnDelete(DeleteBehavior.Cascade);
  builder.Entity<Enrollment>().HasIndex(x=>new {x.ParticipantId,x.EventId}).IsUnique();
  builder.Entity<Enrollment>().HasOne(x=>x.Participant).WithMany(x=>x.Enrollments).HasForeignKey(x=>x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
  builder.Entity<Enrollment>().HasOne(x=>x.Event).WithMany(x=>x.Enrollments).HasForeignKey(x=>x.EventId).OnDelete(DeleteBehavior.Restrict);
  builder.Entity<Enrollment>().HasOne(x=>x.Category).WithMany(x=>x.Enrollments).HasForeignKey(x=>x.CategoryId).OnDelete(DeleteBehavior.Restrict);
  builder.Entity<Result>().HasIndex(x=>x.EnrollmentId).IsUnique();
  builder.Entity<Result>().HasOne(x=>x.Enrollment).WithOne(x=>x.Result).HasForeignKey<Result>(x=>x.EnrollmentId).OnDelete(DeleteBehavior.Cascade);
 }
}