# RaceDay test checklist

- [ ] Application starts after SQL Server is available and migrations are applied.
- [ ] Database contains Identity tables and Events, Categories, Enrollments, Results.
- [ ] Admin, Organiser, Participant roles are seeded.
- [ ] Development admin account is created from `SeedAdmin` settings; change its password before deployment.
- [ ] New registration validates required fields, unique email, password rules, and confirmation.
- [ ] New registration is automatically assigned Participant role.
- [ ] Invalid login is rejected; valid login works; logout clears session.
- [ ] Anonymous visitor can browse event list and details but cannot create events or enrol.
- [ ] Participant can enrol in a future event and cannot enrol twice in the same event.
- [ ] Participant cannot enrol in a category belonging to another event.
- [ ] Organiser can create and edit their own events, but cannot edit another organiser's event.
- [ ] Admin can open admin dashboard and manage events/categories/results.
- [ ] Results prevent duplicate result per enrollment and require positive position when supplied.
- [ ] Validation messages and error page display correctly.
- [ ] Responsive layout is checked on desktop and mobile widths.
