# RaceDay MVC — clean Part 2 rebuild

This is a clean ASP.NET Core MVC implementation based on the Part 1 RaceDay System plan. It targets .NET 8, SQL Server, Entity Framework Core, and ASP.NET Core Identity.

## Requirements
- Visual Studio 2022 with the ASP.NET and web development workload, or .NET 8 SDK
- SQL Server LocalDB (included with many Visual Studio installations) or a SQL Server instance
- EF Core CLI tools: `dotnet tool install --global dotnet-ef` (if not already installed)

## Run it
1. Extract the ZIP and open `RaceDayMVC.csproj` in Visual Studio.
2. Edit `appsettings.json` `ConnectionStrings:DefaultConnection` for your SQL Server. The default uses LocalDB.
3. Open a terminal in the project folder and run:

   ```powershell
   dotnet restore
   dotnet tool install --global dotnet-ef
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   dotnet run
   ```

   If `dotnet-ef` is already installed, skip its installation command. The app runs migrations on startup too, but the initial migration must first be generated.
4. Open the local HTTPS URL printed in the terminal.

## Development admin
The default development seed creates `admin@raceday.local` with password `ChangeMe123!`. Change these values in `appsettings.json` before first run and do not deploy this development credential to production. If the user already exists, seeding does not reset its password.

## Roles
- `Admin`: admin dashboard, event/category/result management
- `Organiser`: create and edit own events, manage categories/results
- `Participant`: register, browse and enrol in events

Public self-registration always assigns `Participant`; users cannot choose Admin or Organiser during registration. An administrator must assign elevated roles through a controlled admin workflow (not public registration).

## Database design
`ApplicationDbContext` extends `IdentityDbContext<ApplicationUser>`. Identity owns user credentials and roles; domain tables use string Identity user IDs for event organisers and participants. Constraints preserve one enrollment per participant/event and one result per enrollment. The original Part 1 SQL uses integer `UserID`; this implementation deliberately migrates the model to Identity's string IDs instead of maintaining a duplicate authentication database.

## Scope notes
This is a clean baseline intended to be opened and tested in Visual Studio. The execution environment used to generate this ZIP does not have the .NET SDK, so the project could not be compiled here. Follow `docs/TEST_CHECKLIST.md`, fix any environment-specific issues, and generate `database/RaceDayDB.sql` from the migration once the project builds.
