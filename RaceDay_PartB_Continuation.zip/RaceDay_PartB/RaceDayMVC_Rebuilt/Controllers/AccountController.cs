using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using RaceDayMVC.Models; using RaceDayMVC.Models.ViewModels;
namespace RaceDayMVC.Controllers;
public class AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager):Controller
{
 [HttpGet] public IActionResult Register()=>User.Identity?.IsAuthenticated==true?RedirectToAction("Index","Home"):View();
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Register(RegisterViewModel model){if(!ModelState.IsValid)return View(model); var user=new ApplicationUser{UserName=model.Email,Email=model.Email,FirstName=model.FirstName.Trim(),LastName=model.LastName.Trim(),CreatedAt=DateTime.UtcNow}; var result=await userManager.CreateAsync(user,model.Password); if(result.Succeeded){await userManager.AddToRoleAsync(user,"Participant"); await signInManager.SignInAsync(user,false); return RedirectToAction("Index","Home");} foreach(var error in result.Errors)ModelState.AddModelError(string.Empty,error.Description); return View(model);}
 [HttpGet] public IActionResult Login(string? returnUrl=null)=>View(new LoginViewModel{ReturnUrl=returnUrl});
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Login(LoginViewModel model){if(!ModelState.IsValid)return View(model); var result=await signInManager.PasswordSignInAsync(model.Email,model.Password,model.RememberMe,false); if(result.Succeeded){if(!string.IsNullOrWhiteSpace(model.ReturnUrl)&&Url.IsLocalUrl(model.ReturnUrl))return LocalRedirect(model.ReturnUrl);return RedirectToAction("Index","Home");} ModelState.AddModelError(string.Empty,"Invalid login attempt.");return View(model);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Logout(){await signInManager.SignOutAsync();return RedirectToAction("Index","Home");}
 public IActionResult AccessDenied()=>View();
}