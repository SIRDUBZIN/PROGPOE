using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDayMVC.Data;using RaceDayMVC.Models;
namespace RaceDayMVC.Controllers;
[Authorize(Roles="Admin,Organiser")] public class ResultsController(ApplicationDbContext db):Controller
{
 public async Task<IActionResult> Index()=>View(await db.Results.Include(r=>r.Enrollment).ThenInclude(e=>e!.Participant).Include(r=>r.Enrollment).ThenInclude(e=>e!.Event).OrderBy(r=>r.FinishingPosition).ToListAsync());
 public async Task<IActionResult> Create(){ViewBag.Enrollments=await db.Enrollments.Include(e=>e.Participant).Include(e=>e.Event).Where(e=>e.Result==null).ToListAsync();return View();}
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult>Create(Result model){if(ModelState.IsValid){if(await db.Results.AnyAsync(r=>r.EnrollmentId==model.EnrollmentId)){ModelState.AddModelError(nameof(model.EnrollmentId),"A result already exists for this enrollment.");}else{db.Results.Add(model);await db.SaveChangesAsync();return RedirectToAction(nameof(Index));}}ViewBag.Enrollments=await db.Enrollments.Include(e=>e.Participant).Include(e=>e.Event).Where(e=>e.Result==null).ToListAsync();return View(model);}
}