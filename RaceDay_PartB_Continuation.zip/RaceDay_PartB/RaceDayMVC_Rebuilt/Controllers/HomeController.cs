using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore; using RaceDayMVC.Data; using RaceDayMVC.Models; using RaceDayMVC.Models.ViewModels; using System.Diagnostics;
namespace RaceDayMVC.Controllers;
public class HomeController(ApplicationDbContext db):Controller
{
 public async Task<IActionResult> Index(){ViewBag.Upcoming=await db.Events.Where(e=>e.EventDate>=DateTime.Now).OrderBy(e=>e.EventDate).Take(6).ToListAsync(); return View();}
 public IActionResult Error()=>View(new ErrorViewModel{RequestId=Activity.Current?.Id??HttpContext.TraceIdentifier});
}