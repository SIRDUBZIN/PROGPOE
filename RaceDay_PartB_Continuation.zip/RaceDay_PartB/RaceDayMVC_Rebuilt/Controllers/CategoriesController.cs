using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.EntityFrameworkCore;using RaceDayMVC.Data;using RaceDayMVC.Models;
namespace RaceDayMVC.Controllers;
[Authorize(Roles="Admin,Organiser")] public class CategoriesController(ApplicationDbContext db):Controller
{
 public async Task<IActionResult> Index()=>View(await db.Categories.Include(c=>c.Event).OrderBy(c=>c.Event!.EventDate).ToListAsync());
 public async Task<IActionResult> Create(){ViewBag.Events=await db.Events.OrderBy(e=>e.EventName).ToListAsync();return View();}
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult>Create(Category model){if(ModelState.IsValid){db.Categories.Add(model);await db.SaveChangesAsync();return RedirectToAction(nameof(Index));}ViewBag.Events=await db.Events.ToListAsync();return View(model);}
}