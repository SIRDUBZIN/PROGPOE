using System.ComponentModel.DataAnnotations;
namespace RaceDayMVC.Models.ViewModels;
public class RegisterViewModel
{
 [Required, StringLength(100)] public string FirstName { get; set; } = "";
 [Required, StringLength(100)] public string LastName { get; set; } = "";
 [Required, EmailAddress] public string Email { get; set; } = "";
 [Required, DataType(DataType.Password), MinLength(8)] public string Password { get; set; } = "";
 [Required, DataType(DataType.Password), Compare(nameof(Password))] public string ConfirmPassword { get; set; } = "";
}