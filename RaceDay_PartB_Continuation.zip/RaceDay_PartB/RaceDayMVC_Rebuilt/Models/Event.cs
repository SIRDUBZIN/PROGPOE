using System.ComponentModel.DataAnnotations;
namespace RaceDayMVC.Models;
public class Event
{
    public int EventId { get; set; }
    [Required, StringLength(150)] public string EventName { get; set; } = string.Empty;
    [Required, StringLength(500)] public string Description { get; set; } = string.Empty;
    [Required] public DateTime EventDate { get; set; }
    [Required, StringLength(150)] public string Location { get; set; } = string.Empty;
    [Range(0.1, 9999)] public decimal Distance { get; set; }
    [Required] public string EventType { get; set; } = "Run";
    [Required] public string OrganiserId { get; set; } = string.Empty;
    public ApplicationUser? Organiser { get; set; }
    public ICollection<Category> Categories { get; set; } = new List<Category>();
    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}