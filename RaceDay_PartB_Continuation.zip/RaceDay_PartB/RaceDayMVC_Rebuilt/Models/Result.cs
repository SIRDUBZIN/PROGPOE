using System.ComponentModel.DataAnnotations;
namespace RaceDayMVC.Models;
public class Result
{
    public int ResultId { get; set; }
    public int EnrollmentId { get; set; }
    public Enrollment? Enrollment { get; set; }
    public TimeSpan? FinishTime { get; set; }
    [Range(1, int.MaxValue)] public int? FinishingPosition { get; set; }
}