namespace RaceDayMVC.Models;
public class Enrollment
{
    public int EnrollmentId { get; set; }
    public string ParticipantId { get; set; } = string.Empty;
    public ApplicationUser? Participant { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
    public DateTime EnrollmentDate { get; set; } = DateTime.UtcNow;
    public Result? Result { get; set; }
}