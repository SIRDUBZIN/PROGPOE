using System.ComponentModel.DataAnnotations;
namespace RaceDayMVC.Models;
public class Category
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public Event? Event { get; set; }
    [Required, StringLength(100)] public string CategoryName { get; set; } = string.Empty;
    [StringLength(250)] public string? Description { get; set; }
    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}