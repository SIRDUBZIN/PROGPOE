# Database and ERD notes

This clean rebuild uses ASP.NET Core Identity tables for authentication and roles. EF Core migrations create `AspNetUsers`, `AspNetRoles`, join tables, and the RaceDay domain tables `Events`, `Categories`, `Enrollments`, and `Results`.

The original Part 1 `Users` and `Roles` tables are intentionally not recreated as parallel login tables. Identity is the source of truth for users and roles. Domain foreign keys use the Identity user string key.

After creating the first migration, generate an updated SQL script with:

```powershell
dotnet ef migrations script -o database/RaceDayDB.sql
```
